<?php
/**
 * The sidebar for content page
 *
 * If no active widgets are in the sidebar, hide it completely.
 *
 * @package WordPress
 * @subpackage Autima_Theme
 * @since Autima 1.0
 */
$autima_opt = get_option( 'autima_opt' );
$autima_page_sidebar_extra_class = NULl;
if($autima_opt['sidebarse_pos']=='left') {
	$autima_page_sidebar_extra_class = 'order-lg-first';
}
?>
<?php if ( is_active_sidebar( 'sidebar-page' ) ) : ?>
<div id="secondary" class="col-12 col-lg-3 <?php echo esc_attr($autima_page_sidebar_extra_class);?>">
	<div class="sidebar-content">
		<?php dynamic_sidebar( 'sidebar-page' ); ?>
	</div>
</div>
<?php endif; ?>