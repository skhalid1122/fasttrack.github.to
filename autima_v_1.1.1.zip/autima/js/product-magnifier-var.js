"use strict";
// product-magnifier var
var autima_magnifier_vars;

var yith_magnifier_options = {
	showTitle: false,
	zoomWidth: autima_magnifier_vars.zoomWidth,
	zoomHeight: autima_magnifier_vars.zoomHeight,
	position: autima_magnifier_vars.position,
	lensOpacity: autima_magnifier_vars.lensOpacity,
	softFocus: autima_magnifier_vars.softFocus,
	adjustY: 0,
	disableRightClick: false,
	phoneBehavior: autima_magnifier_vars.phoneBehavior,
	loadingLabel: autima_magnifier_vars.loadingLabel,
}
var sliderOptions = {
		responsive: autima_magnifier_vars.responsive,
		circular: autima_magnifier_vars.circular,
		infinite: autima_magnifier_vars.infinite,
		direction: 'left',
		debug: false,
		auto: false,
		align: 'left', 
		prev    : {
			button  : "#slider-prev",
			key     : "left"
		},
		next    : {
			button  : "#slider-next",
			key     : "right"
		},
		scroll : {
			items     : 1,
			pauseOnHover: true
		},
		items   : {
			visible: Number(autima_magnifier_vars.visible),
		},
		swipe : {
			onTouch:    true,
			onMouse:    true
		},
		mousewheel : {
			items: 1
		}
	};
		
jQuery('ul.yith_magnifier_gallery').carouFredSel(sliderOptions);